

//
// Name                 Seamus Robinson
// Student ID           S1511581
// Programme of Study   Computing
//



package gcu.mpd.bgsdatastarter.mpdresit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import gcu.mpd.bgsdatastarter.mpdresit.R;

public class MainActivity extends AppCompatActivity implements OnClickListener {
    private TextView rawDataDisplay;
    private Button startButton;
    private String result;
    private String url1 = "";
    private String urlSource = "https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2648579";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Set up the raw links to the graphical components
        //rawDataDisplay = (TextView) findViewById(R.id.WGlas1);
        //startButton = (Button) findViewById(R.id.WGlas);






            ArrayList<String> description = new ArrayList<>();

            RetrieveWeatherData getXML = new RetrieveWeatherData();
            getXML.execute();
            description = getXML.desc();
            ArrayAdapter adapter = new ArrayAdapter(this,
                    android.R.layout.simple_list_item_1, description);
            //setListAdapter(adapter);
        }


    @Override
    public void onClick(View v) {

    }
}




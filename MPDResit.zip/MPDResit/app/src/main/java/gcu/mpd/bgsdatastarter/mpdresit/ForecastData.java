//
// Name                 Seamus Robinson
// Student ID           S1511581
// Programme of Study   Computing
//

package gcu.mpd.bgsdatastarter.mpdresit;

import java.util.Date;

public class ForecastData {

        private Double MaxTemp;
        private Double MinTemp;
        private String WindDir;
        private int WindSpd;
        private Date date;

        public ForecastData()
        {
            MaxTemp = 0.0;
            MinTemp = 0.0;
            WindDir = "";
            WindSpd = 0;
            date =  new Date();
        }

        public ForecastData(Double aMaxTemp,Double aMinTemp,String aWindDir, int aWindSpd, Date adate)
        {
            MaxTemp = aMaxTemp;
            MinTemp = aMinTemp;
            WindDir = aWindDir;
            WindSpd = aWindSpd;
            date = adate;
        }

        public Double getMaxTemp()
        {
            return MaxTemp;
        }

        public void setMaxTemp(Double aMaxTemp)
        {
            MaxTemp = aMaxTemp;
        }

        public Double getMinTemp()
        {
            return MinTemp;
        }

        public void setMinTemp(Double aMinTemp)
        {
            MinTemp = aMinTemp;
        }

        public String getWindDir()
        {
            return WindDir;
        }

        public void setWindDir(String aWindDir)
        {
            WindDir = aWindDir;
        }

        public int getWindSpd(){
            return WindSpd;
        }

       public Date getDate(){
            return date;
       }
       public void setDate(Date date){
            date= date;
       }


        public String toString()
        {
            String temp;

            temp = MaxTemp + " " + MinTemp + " " + WindDir + " " + WindSpd + " " + date;

            return temp;
        }

    } // End of class

